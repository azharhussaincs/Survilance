package com.cms.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Central application configuration manager.
 * Loads from config file with sensible defaults.
 */
public class AppConfig {
    private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);
    private static AppConfig instance;
    private final Properties properties = new Properties();
    private static final String CONFIG_FILE = "cms.properties";
    private static final String USER_HOME_CONFIG = System.getProperty("user.home") + "/.cms/" + CONFIG_FILE;

    private AppConfig() {
        loadConfig();
    }

    public static synchronized AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }

    private void loadConfig() {
        // Load defaults from classpath
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (is != null) {
                properties.load(is);
                logger.info("Loaded default config from classpath");
            }
        } catch (IOException e) {
            logger.warn("Could not load default config: {}", e.getMessage());
        }

        // Override with user config if exists
        Path userConfig = Paths.get(USER_HOME_CONFIG);
        if (Files.exists(userConfig)) {
            try (InputStream is = Files.newInputStream(userConfig)) {
                properties.load(is);
                logger.info("Loaded user config from: {}", USER_HOME_CONFIG);
            } catch (IOException e) {
                logger.warn("Could not load user config: {}", e.getMessage());
            }
        }

        setDefaults();
    }

    private void setDefaults() {
        properties.putIfAbsent("db.url", "jdbc:mysql://localhost:3306/cms_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        properties.putIfAbsent("db.username", "root");
        properties.putIfAbsent("db.password", "");
        properties.putIfAbsent("db.pool.size", "10");
        properties.putIfAbsent("app.name", "CMS - Camera Management System");
        properties.putIfAbsent("app.version", "1.0.0");
        properties.putIfAbsent("stream.connection.timeout", "10000");
        properties.putIfAbsent("stream.read.timeout", "30000");
        properties.putIfAbsent("onvif.discovery.timeout", "5000");
        properties.putIfAbsent("nvr.connect.timeout", "15000");
        properties.putIfAbsent("ui.theme", "dark");
    }

    public String get(String key) {
        return properties.getProperty(key);
    }

    public String get(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public int getInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(properties.getProperty(key, String.valueOf(defaultValue)));
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        String val = properties.getProperty(key);
        if (val == null) return defaultValue;
        return Boolean.parseBoolean(val);
    }

    public void set(String key, String value) {
        properties.setProperty(key, value);
    }

    public void save() {
        Path configDir = Paths.get(System.getProperty("user.home") + "/.cms");
        try {
            Files.createDirectories(configDir);
            try (OutputStream os = Files.newOutputStream(configDir.resolve(CONFIG_FILE))) {
                properties.store(os, "CMS Application Configuration");
            }
        } catch (IOException e) {
            logger.error("Could not save config: {}", e.getMessage());
        }
    }
}
